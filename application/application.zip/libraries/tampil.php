<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class RegresiPolinomialLaporan {

	private static $CI;
    private $X, $Y, $Y2, $B, $matrix, $jum, $orde;

    public function __construct()
    {
        self::$CI = & get_instance();
        $this->jum = 12;

    }

    public function initAwal(){
        $X = $this->X;
        $Y = $this->Y;
        $jum = $this->jum;
        for($i= 0; $i<=$jum;$i++){
            $X[$i][0] = 0;
        }

        for($i= 0; $i<=$jum/2;$i++){
            $Y[$i][0] = 0;
        }

        for($i = 1;$i<=$jum;$i++){
            for($j = 1;$j<=$jum;$j++){
                $X[$i][$j] = pow($X[1][$j],$i);
                $X[$i][0] += $X[$i][$j];
                if($i<=$jum/2){
                    $Y[$i][$j] = $X[$i][$j]*$Y[0][$j];
                    $Y[$i][0] += $Y[$i][$j];
                }
                if($i==1){
                    $Y[0][0] += $Y[0][$j];
                }
            }
        }
        $this->X = $X;
        $this->Y = $Y;
    }

    public function initMatrix(){
        $X = $this->X;
        $Y = $this->Y;
        $jum = $this->jum;
        $matrix = $this->matrix;

        for ($i=0; $i < ($jum/2)+1; $i++) { 
            for ($j=0; $j < ($jum/2)+2; $j++) { 
                if($i== 0&& $j==0){
                    $matrix[$i][$j] = $jum;
                }else if($j+1<($jum/2)+2){
                    $matrix[$i][$j] = $X[($i+$j)][0];
                }else{
                    $matrix[$i][$j] = $Y[$i][0];
                }
            }
        }

        $this->X = $X;
        $this->Y = $Y;
        $this->matrix = $matrix;
    }



    public function tampilAwal($produk_pilihan, $orde = 6, $tampilAll = true){
        $this->jum = 2*$orde;
       ?>
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Menampilkan tabel dan grafik</a></h3>
            </div><!-- /.box-header -->
            <div class="box-body">
              <div class="row">
                <div class="col-md-3  table-responsive">
                  
                    <?php
                      $no=1;
                      $this->orde = $orde;
                      foreach ($produk_pilihan as $key) {
                        $this->X[1][$no] = $key->id_bulan;
                        $this->Y[0][$no] = $key->total_stok;
                    ?>

                    <?php
                      $no++;
                      }
                      //print_r($this->X[1][2]);
                    ?>
                </div>
              </div>
              <?php $this->proses(); ?>
            </div><!-- /.box-body -->
          </div><!-- /.box-primary -->
        </div><!-- /.col-md -->
      </div><!-- /.row -->
    </section>
       <?php
    }

    public function proses(){
        //mpemberian data awal X dan Y
        $this->initAwal();

        //memberikan data awal untuk matrix
        $this->initMatrix();

        //menjalankan rumus gauss serta menampilkannya
        $this->gauss();

        //pencarian nilai b dan Y topi
        $this->pencarianNilai();

        //menampilkan grafik hasil
        $this->tampilGrafik();

        // echo "<pre>";
        // print_r($this->matrix);
        // echo "</pre>";

    }

    public function gauss(){
        $jum = $this->jum;
        $matrix = $this->matrix;
        
        
        //$this->tampilMatrix($matrix);
        for ($i=0; $i <= $jum/2; $i++) { 
            $pesan = array();
            for ($j=$i; $j <= $jum/2; $j++) { 
                
                if($i==$j){
                    $temp = $matrix[$i][$j];
                    for ($k=0; $k <= ($jum/2)+1; $k++) { 
                        $matrix[$i][$k] /=$temp;
                    }
                    array_push($pesan,"B$i <-- B$i/$temp");
                    $pesan = array();
                }else{
                    $temp = $matrix[$j][$i];
                    for ($k=0; $k <= ($jum/2)+1; $k++) { 
                        $matrix[$j][$k] =$matrix[$j][$k] - ($temp*$matrix[$i][$k]);
                    }
                    array_push($pesan,"B$j <-- B$j - (B$i*$temp)");
                }
            }
            
            //$this->tampilMatrix($matrix,$pesan);
        }

        $this->matrix = $matrix;
    }

    public function pencarianNilai(){
        $jum = $this->jum;
        $matrix = $this->matrix;
        $no = $jum/2;

        for ($i=0; $i <= $no ; $i++) { 
            $B[$i] = 0;
            $tampilB[$i] = 'B'.$i.' = ';
            $tampilRumusB[$i] = 'B'.$i.' = ';
        }
        for ($i=$no; $i >= 0; $i--) { 
            for ($j=$i; $j <= $no ; $j++) { 
                if($i == $j){
                    $B[$i] = $matrix[$i][$no+1];
                    $tampilB[$i] = $tampilB[$i].$B[$i];
                    $tampilRumusB[$i] = $tampilRumusB[$i].$B[$i];
                }else{
                    $B[$i] -= $matrix[$i][$j]*$B[$j];
                    $tampilB[$i] = $tampilB[$i]." - (".$matrix[$i][$j]." * ".$B[$j].")";
                    $tampilRumusB[$i] = $tampilRumusB[$i]." - (".$matrix[$i][$j]." * B$j)";
                }
                
            }
        }
        for ($i=0; $i <= $jum+1; $i++) { 
            $Y2[$i] = 0;
            $tampilY2[$i] = 'Ý'.$i.' = ';
            $tampilRumusY2[$i] = 'Ý'.$i.' = ';
        }

        for ($i=1; $i <= $jum+1; $i++) { 
            for ($j=0; $j <=$this->orde; $j++) { 
                if($j!=0){
                    $Y2[$i] += $B[$j]*pow($i, $j);
                    $tampilRumusY2[$i] = $tampilRumusY2[$i]." + B$j(X<sup>$j</sup>)";
                    $tampilY2[$i] = $tampilY2[$i]." + ".$B[$j]."(".$i."<sup>$j</sup>)";
                }
                else{
                    $Y2[$i] += $B[$j];
                    $tampilRumusY2[$i] = $tampilRumusY2[$i]."B$j";
                    $tampilY2[$i] = $tampilY2[$i].$B[$j]."";
                }
            }
        }

        $this->B = $B;
        $this->Y2 = $Y2;

    }

    public function tampilGrafik(){
        ?>
          <div class="row">
            <div class="col-md-6">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr style="background-color: #cccc14;">
                            <th>i</th>
                            <th>X</th>
                            <th>Y</th>
                            <th>Ý</th>
                            <th>∈ = Y - Ý</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php for ($i=1; $i <= $this->jum+1; $i++) { ?>
                        <tr <?=$i!=$this->jum+1?'':'style="background-color: #fbcccc;"'?>>
                            <td><?=$i?></td>
                            <td><?=$i?></td>
                            <td><?=$i!=$this->jum+1?$this->Y[0][$i]:''?></td>
                            <td><?=$this->Y2[$i]?></td>
                            <td><?=$i!=$this->jum+1?($this->Y[0][$i] - $this->Y2[$i]):''?></td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
            <div class="col-md-6">
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Grafik</h3>
                  <div class="box-tools pull-right">
                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                  </div>
                </div>
                <div class="box-body">
                  <div class="chart">
                    <canvas id="lineChart" style="height:350px"></canvas>
                  </div>
                  <div class="col-md-12">
                      <div class="col-md-1" style="background-color: #A52A2A; width: 15px; height: 15px;"></div>
                      <div class="col-md-6" style="padding-left: 10px"> Kurva data real</div>
                  </div>
                  <div class="col-md-12">
                      <div class="col-md-1" style="background-color: #0000FF; width: 15px; height: 15px;"></div>
                      <div class="col-md-6" style="padding-left: 10px"> Kurva data prediksi</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
      <!-- /.row -->
    <script type="text/javascript">
         periode = [<?php for($i=1;$i<=$this->jum;$i++){ echo $i.", "; } ?>];
         data1 = [<?php for($i=1;$i<=$this->jum;$i++){ echo $this->Y[0][$i].", "; } ?>];
         data2 = [<?php for($i=1;$i<=$this->jum;$i++){ echo $this->Y2[$i].", "; } ?>];
    </script>

        <?php
    }
}
?>